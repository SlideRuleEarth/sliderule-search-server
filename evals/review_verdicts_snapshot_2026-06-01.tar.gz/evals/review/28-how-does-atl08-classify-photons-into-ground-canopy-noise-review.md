# Row 28 review

> Companion to `28-how-does-atl08-classify-photons-into-ground-canopy-noise-results.md`. Open both side-by-side;
> this file is your editable form.

**Query:** `how does ATL08 classify photons into ground canopy noise`
**Labeled corpus:** `nsidc`

---

## Per-result verdicts

Mark each result `correct`, `partial`, or `wrong`. Leave blank to skip.

**docsearch:**

- r1: partial
- r2: wrong
- r3: partial
- r4: partial
- r5: wrong

**nsidc:**

- r1: correct
- r2: wrong
- r3: correct
- r4: correct
- r5: partial

## Overall verdict

One of: `correct` | `partial` | `wrong`

- overall: correct

## Cross-corpus routing

Should this query target a different corpus? One of:
`keep` | `redirect-to-docsearch` | `redirect-to-nsidc` | `both-corpora`

- routing: keep

## Human truth (the actual right answer)

If the right answer was returned at some rank, you can leave these
blank — the per-result verdicts above already capture that. Fill
these in **only if** the correct answer is not in either result set,
or if you want to override what's correct.

Repeat any field on a new `- field: value` line for multiple values.

- corpus: 
- url: 
- section: 
- pages: 
- notes: 

