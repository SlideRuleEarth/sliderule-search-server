# Row 93 review

> Companion to `93-read-cloud-hdf5-files-without-downloading-them-results.md`. Open both side-by-side;
> this file is your editable form.

**Query:** `read cloud HDF5 files without downloading them`
**Labeled corpus:** `docsearch`

---

## Per-result verdicts

Mark each result `correct`, `partial`, or `wrong`. Leave blank to skip.

**docsearch:**

- r1: 
- r2: 
- r3: 
- r4: 
- r5: 

**nsidc:**

- r1: 
- r2: 
- r3: 
- r4: 
- r5: 

## Overall verdict

One of: `correct` | `partial` | `wrong`

- overall: 

## Cross-corpus routing

Should this query target a different corpus? One of:
`keep` | `redirect-to-docsearch` | `redirect-to-nsidc` | `both-corpora`

- routing: 

## Human truth (the actual right answer)

If the right answer was returned at some rank, you can leave these
blank — the per-result verdicts above already capture that. Fill
these in **only if** the correct answer is not in either result set,
or if you want to override what's correct.

Repeat any field on a new `- field: value` line for multiple values.

- corpus: 
- url: 
- section: 
- pages: 
- notes: 

